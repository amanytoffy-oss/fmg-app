-- FMG – Find My Gift : قاعدة البيانات (نسخة مُؤمَّنة)
-- الصقي هذا الملف كله في Supabase > SQL Editor ثم اضغطي Run
--
-- إذا سبق وشغّلتي النسخة القديمة على نفس المشروع، شغّلي هذا السطر أولاً بـ query منفصل
-- (ينمسح كل شي بالقاعدة: القوائم والهدايا والحجوزات):
--   drop table if exists public.reservations, public.gifts, public.lists, public.profiles cascade;

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null check (username ~ '^[a-z0-9_]{3,20}$'),
  display_name text not null default '' check (char_length(display_name) <= 30),
  created_at timestamptz not null default now()
);

create table public.lists (
  id uuid primary key default gen_random_uuid(),
  owner uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 80),
  emoji text not null default '🎁' check (char_length(emoji) <= 16),
  created_at timestamptz not null default now()
);
create index lists_owner_idx on public.lists(owner);

create table public.gifts (
  id uuid primary key default gen_random_uuid(),
  list_id uuid not null references public.lists(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 100),
  price integer check (price is null or price >= 0),
  link text check (link is null or char_length(link) <= 500),
  store text check (store is null or char_length(store) <= 80),
  story text check (story is null or char_length(story) <= 500),
  emoji text not null default '🎁' check (char_length(emoji) <= 16),
  received boolean not null default false,
  created_at timestamptz not null default now()
);
create index gifts_list_idx on public.gifts(list_id);

-- الحجوزات: ما أحد يكدر يقراها مباشرة (حتى صاحبة القائمة) حتى تبقى مفاجأة.
create table public.reservations (
  id uuid primary key default gen_random_uuid(),
  gift_id uuid not null unique references public.gifts(id) on delete cascade,
  name text,
  message text,
  token uuid not null default gen_random_uuid(),
  ip_hash text,                       -- بصمة مشفّرة للـ IP لتحديد عدد الحجوزات (مو الـ IP نفسه)
  expires_at timestamptz not null,
  created_at timestamptz not null default now()
);
create index reservations_ip_idx on public.reservations(ip_hash, created_at);

alter table public.profiles enable row level security;
alter table public.lists enable row level security;
alter table public.gifts enable row level security;
alter table public.reservations enable row level security;  -- بدون سياسات = ممنوع الوصول المباشر

-- القراءة المباشرة من الجداول صارت لصاحبة البيانات فقط.
-- الزوار يقرون فقط عن طريق الدوال تحت (لازم يعرفون رابط القائمة أو اليوزر)،
-- فما أحد يكدر يسحب كل القوائم أو كل المستخدمين مرة وحدة.

-- profiles
create policy "profiles_read_own" on public.profiles for select using (id = auth.uid());
create policy "profiles_insert" on public.profiles for insert with check (id = auth.uid());
create policy "profiles_update" on public.profiles for update using (id = auth.uid()) with check (id = auth.uid());

-- lists
create policy "lists_read_own" on public.lists for select using (owner = auth.uid());
create policy "lists_insert" on public.lists for insert with check (owner = auth.uid());
create policy "lists_update" on public.lists for update using (owner = auth.uid()) with check (owner = auth.uid());
create policy "lists_delete" on public.lists for delete using (owner = auth.uid());

-- gifts
create policy "gifts_read_own" on public.gifts for select
  using (exists (select 1 from public.lists l where l.id = list_id and l.owner = auth.uid()));
create policy "gifts_insert" on public.gifts for insert
  with check (exists (select 1 from public.lists l where l.id = list_id and l.owner = auth.uid()));
create policy "gifts_update" on public.gifts for update
  using (exists (select 1 from public.lists l where l.id = list_id and l.owner = auth.uid()))
  with check (exists (select 1 from public.lists l where l.id = list_id and l.owner = auth.uid()));
create policy "gifts_delete" on public.gifts for delete
  using (exists (select 1 from public.lists l where l.id = list_id and l.owner = auth.uid()));

-- ===== دوال =====

-- الصفحة العامة لليوزر: الاسم والقوائم فقط.
create or replace function public.get_user_page(p_username text)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare p public.profiles;
begin
  select * into p from public.profiles where username = lower(p_username);
  if not found then return null; end if;
  return jsonb_build_object(
    'profile', jsonb_build_object('username', p.username, 'display_name', p.display_name),
    'lists', coalesce((
      select jsonb_agg(jsonb_build_object('id', l.id, 'title', l.title, 'emoji', l.emoji)
                       order by l.created_at desc)
      from public.lists l where l.owner = p.id
    ), '[]'::jsonb)
  );
end $$;

-- قائمة كاملة مع حالة الحجز.
-- اسم الحاجز والكارت وكونه مجهول أو لا: ما يطلعون لأي أحد، إلا لصاحبة القائمة بعد "استلمتها".
-- هيج حتى لو صاحبة القائمة فتحت رابطها من نافذة خاصة أو بعد تسجيل الخروج، ما تشوف منو حجز.
-- p_tokens: رموز الحجز المخزونة بمتصفح الزائر، حتى نكدر نكوله "هذا حجزج انتِ".
create or replace function public.get_list(p_id uuid, p_tokens uuid[] default '{}')
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare l public.lists; own boolean;
begin
  select * into l from public.lists where id = p_id;
  if not found then return null; end if;
  own := (auth.uid() is not null and auth.uid() = l.owner);
  return jsonb_build_object(
    'list', to_jsonb(l),
    'mine', own,
    'owner', (select jsonb_build_object('username', username, 'display_name', display_name)
              from public.profiles where id = l.owner),
    'gifts', coalesce((
      select jsonb_agg(jsonb_build_object(
        'id', g.id, 'name', g.name, 'price', g.price, 'link', g.link, 'store', g.store,
        'story', g.story, 'emoji', g.emoji, 'received', g.received,
        'reserved', (r.id is not null and (r.expires_at > now() or g.received)),
        'until', case when r.id is not null and r.expires_at > now() then r.expires_at end,
        'yours', (r.id is not null and not own and r.token = any(coalesce(p_tokens, '{}'))),
        'anon', case when own and g.received then (r.id is not null and r.name is null) end,
        'by', case when own and g.received then r.name end,
        'message', case when own and g.received then r.message end
      ) order by g.created_at)
      from public.gifts g
      left join public.reservations r on r.gift_id = g.id
      where g.list_id = l.id
    ), '[]'::jsonb)
  );
end $$;

-- بصمة الـ IP للطلب الحالي (مشفّرة، ما نخزن الـ IP نفسه).
create or replace function public._req_ip_hash()
returns text language plpgsql stable set search_path = public as $$
declare hdr json; ip text;
begin
  begin
    hdr := nullif(current_setting('request.headers', true), '')::json;
  exception when others then
    return null;
  end;
  if hdr is null then return null; end if;
  ip := nullif(trim(split_part(coalesce(hdr->>'cf-connecting-ip', hdr->>'x-forwarded-for', ''), ',', 1)), '');
  if ip is null then return null; end if;
  return md5('fmg:' || ip);
end $$;
revoke execute on function public._req_ip_hash() from public, anon, authenticated;

-- حجز هدية. يرجع رمز سري يخزنه المتصفح حتى تكدر الحاجزة تلغي حجزها.
-- حد الحجوزات: 3 حجوزات فعّالة بنفس القائمة، و10 حجوزات بالساعة، لكل اتصال إنترنت (IP).
create or replace function public.reserve_gift(p_gift uuid, p_name text, p_message text, p_hours int)
returns uuid language plpgsql security definer set search_path = public as $$
declare own uuid; rec boolean; lid uuid; tok uuid; ih text;
begin
  if p_hours not in (24, 48, 168) then raise exception 'bad_duration'; end if;
  select l.owner, g.received, g.list_id into own, rec, lid
    from public.gifts g join public.lists l on l.id = g.list_id where g.id = p_gift;
  if not found then raise exception 'not_found'; end if;
  if rec then raise exception 'taken'; end if;
  if own = auth.uid() then raise exception 'owner'; end if;

  ih := public._req_ip_hash();
  if ih is not null then
    if (select count(*) from public.reservations r join public.gifts g on g.id = r.gift_id
        where r.ip_hash = ih and g.list_id = lid and r.expires_at > now()) >= 3 then
      raise exception 'limit';
    end if;
    if (select count(*) from public.reservations r
        where r.ip_hash = ih and r.created_at > now() - interval '1 hour') >= 10 then
      raise exception 'limit';
    end if;
  end if;

  delete from public.reservations where gift_id = p_gift and expires_at <= now();
  begin
    insert into public.reservations (gift_id, name, message, ip_hash, expires_at)
    values (p_gift, nullif(left(trim(coalesce(p_name, '')), 40), ''),
            nullif(left(coalesce(p_message, ''), 500), ''), ih, now() + make_interval(hours => p_hours))
    returning token into tok;
  exception when unique_violation then
    raise exception 'taken';
  end;
  return tok;
end $$;

-- الحاجزة تلغي حجزها (بالرمز السري). ما ينلغي بعد ما صاحبة القائمة تستلم الهدية،
-- حتى ما يضيع الاسم والكارت.
create or replace function public.cancel_reservation(p_gift uuid, p_token uuid)
returns void language sql security definer set search_path = public as $$
  delete from public.reservations r
  using public.gifts g
  where r.gift_id = p_gift and r.token = p_token
    and g.id = r.gift_id and not g.received;
$$;

-- صاحبة القائمة تفكّ حجز (إذا شكّت إنه حجز وهمي) بدون ما تعرف منو حاجز.
create or replace function public.release_gift(p_gift uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'auth'; end if;
  delete from public.reservations r
  using public.gifts g, public.lists l
  where r.gift_id = p_gift and g.id = r.gift_id and l.id = g.list_id
    and l.owner = auth.uid() and not g.received;
end $$;

revoke execute on function public.get_user_page(text) from public;
revoke execute on function public.get_list(uuid, uuid[]) from public;
revoke execute on function public.reserve_gift(uuid, text, text, int) from public;
revoke execute on function public.cancel_reservation(uuid, uuid) from public;
revoke execute on function public.release_gift(uuid) from public;

grant execute on function public.get_user_page(text) to anon, authenticated;
grant execute on function public.get_list(uuid, uuid[]) to anon, authenticated;
grant execute on function public.reserve_gift(uuid, text, text, int) to anon, authenticated;
grant execute on function public.cancel_reservation(uuid, uuid) to anon, authenticated;
grant execute on function public.release_gift(uuid) to authenticated;
